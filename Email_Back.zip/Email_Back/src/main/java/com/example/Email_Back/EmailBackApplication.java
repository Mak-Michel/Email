package com.example.Email_Back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailBackApplication.class, args);
	}

}
